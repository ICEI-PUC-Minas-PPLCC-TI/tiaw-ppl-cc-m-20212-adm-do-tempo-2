//dados do usuario
let userLogado = JSON.parse(localStorage.getItem('userLogado'))

let logado = document.querySelector('#logado')

//logado.innerHTML = `Olá ${userLogado.user}`

// if(localStorage.getItem('token') == null){
//     window.location.href = "index.html";
// }

function sair() {
    localStorage.removeItem('token')
    localStorage.removeItem('userLogado')
    localStorage.removeItem('todoList')
    window.location.href = "index.html";
}

//mostrar usuario no cabeçalho

console.log(userLogado)

var cabecalho = document.getElementById("navbar-items")
console.log(cabecalho)

if(!userLogado) {
    console.log("entrou")
} else {
    console.log("entrou")
    document.getElementById("navbar-items").innerHTML = `
        <li><a href="index.html">Início</a></li>  
        <li><a href="sobre.html">Sobre</a></li>
        <li><a href="contato.html">Contato</a></li>
        <li><a href="perfil-usuario.html">Olá ${userLogado.user}</a></li>
        <li><a href="tarefas.html">Minhas Tarefas</a></li>
        <li><a href="index.html" onclick ='sair()'>Sair</a></li>
    `
}

//area de tarefas
'use strict';

let banco = [];

const getBanco = () => JSON.parse(localStorage.getItem ('todoList')) ?? [];
const setBanco = (banco) => localStorage.setItem ('todoList', JSON.stringify(banco));

const criarItem = (nomeTarefa, statusTarefa, indice) => {
    const item = document.createElement('label');
    item.classList.add('todo__item');
    item.innerHTML = `
        <input type="checkbox" ${statusTarefa} data-indice=${indice}>
        <div>${nomeTarefa}</div>
        <input type="button" value="X" data-indice=${indice}>
    `;
    document.getElementById('todoList').appendChild(item);
}

const limparTarefas = () => {
    const todoList = document.getElementById('todoList');
    while (todoList.firstChild) {
        todoList.removeChild(todoList.lastChild);
    }
}

const preencherTarefas = () => {
    let usuarioAtual = localStorage.getItem('userLogado') && JSON.parse(localStorage.getItem('userLogado'))
    usuarioAtual.tarefa = usuarioAtual.tarefa || []
    if (usuarioAtual.tarefa) {
        setBanco(usuarioAtual.tarefa)
    }
}

const atualizarTela = () => {
    limparTarefas();
    const banco = getBanco(); 
    banco.forEach ( (item, indice) => criarItem (item.nomeTarefa, item.statusTarefa, indice));
}

const inserirItem = (evento) => {
    const tecla = evento.key;
    const texto = evento.target.value;
    if (tecla === 'Enter'){
        const banco = getBanco();
        banco.push ({'nomeTarefa': texto, 'statusTarefa': ''});
        atualizarBanco(banco)
        evento.target.value = '';
    }
}

const removerItem = (indice) => {
    const banco = getBanco();
    banco.splice (indice, 1);
    atualizarBanco(banco)
}

const atualizarItem = (indice) => {
    const banco = getBanco();
    banco[indice].statusTarefa = banco[indice].statusTarefa === '' ? 'checked' : '';
    atualizarBanco(banco)
}

const clickItem = (evento) => {
    const elemento = evento.target;
    console.log (elemento.type);
    if (elemento.type === 'button') {
        const indice = elemento.dataset.indice;
        removerItem (indice);
    }else if (elemento.type === 'checkbox') {
        const indice = elemento.dataset.indice;
        atualizarItem (indice);
    }
}

const atualizarBanco = (banco) => {
    setBanco(banco);
    setTarefaUsuario(banco)
    atualizarTela();
}

const setTarefaUsuario = (banco) => {
    let usuarioAtual = localStorage.getItem('userLogado') && JSON.parse(localStorage.getItem('userLogado'))
    if(!usuarioAtual){
        alert('user is not logged')
        return
    }
    usuarioAtual.tarefa = banco
    let listaUser = localStorage.getItem('listaUser') && JSON.parse(localStorage.getItem('listaUser')) || [].push(usuarioAtual)
    const index = listaUser.findIndex(x => x.user == usuarioAtual.user)
    if (index < 0) {
        alert('user is not on listaUser')
        return
    }
    listaUser[index] = usuarioAtual
    localStorage.setItem ('listaUser', JSON.stringify(listaUser));
    localStorage.setItem ('userLogado', JSON.stringify(usuarioAtual));
}

document.getElementById('newItem').addEventListener('keypress', inserirItem);
document.getElementById('todoList').addEventListener('click', clickItem);

preencherTarefas();
atualizarTela();