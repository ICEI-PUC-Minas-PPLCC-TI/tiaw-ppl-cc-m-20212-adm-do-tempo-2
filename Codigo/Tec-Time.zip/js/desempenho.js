//dados do usuario
let userLogado = JSON.parse(localStorage.getItem('userLogado'))

let logado = document.querySelector('#logado')

//logado.innerHTML = `Olá ${userLogado.user}`

// if(localStorage.getItem('token') == null){
//     window.location.href = "index.html";
// }

function sair() {
    localStorage.removeItem('token')
    localStorage.removeItem('userLogado')
    localStorage.removeItem('todoList')
    window.location.href = "index.html";
}

//mostrar usuario no cabeçalho

console.log(userLogado)

var cabecalho = document.getElementById("navbar-items")
console.log(cabecalho)

if(!userLogado) {
    console.log("entrou")
} else {
    console.log("entrou")
    document.getElementById("navbar-items").innerHTML = `
        <li><a href="index.html">Início</a></li>  
        <li><a href="sobre.html">Sobre</a></li>
        <li><a href="contato.html">Contato</a></li>
        <li><a href="desempenho.html">Desempenho</a></li>
        <li><a href="tarefas.html">Tarefas</a></li>
        <li><a href="index.html" onclick ='sair()'>Sair</a></li>
    `
}

// Desempenho

var tarefaCompleta = 0;
var tarefaIncompleta = 0;

const graficoTarefas = () => {
    let usuarioAtual = localStorage.getItem('userLogado') && JSON.parse(localStorage.getItem('userLogado'))
    usuarioAtual.tarefa = usuarioAtual.tarefa || []
    console.log("funcionou")
    for (let index = 0; index < usuarioAtual.tarefa.length; index++) {
        if (usuarioAtual.tarefa[index].statusTarefa == "checked") {
            let nomeMostraTarefa = usuarioAtual.tarefa[index].nomeTarefa
            console.log("entrou no true", index, nomeMostraTarefa, usuarioAtual.tarefa[index].statusTarefa)
            tarefaCompleta++;
            console.log(tarefaCompleta)
        } else {
            let nomeMostraTarefa = usuarioAtual.tarefa[index].nomeTarefa
            console.log("entrou no false", index, nomeMostraTarefa, usuarioAtual.tarefa[index].statusTarefa)
            tarefaIncompleta++;
            console.log(tarefaIncompleta)
        }
    }
}

graficoTarefas();

pieData = [
    { name: 'Tarefas Completas', y: tarefaCompleta },
    { name: 'Tarefas Incompletas', y: tarefaIncompleta }
]
  
  Highcharts.chart('container', {
    chart: {
      plotBackgroundColor: null,
      plotBorderWidth: null,
      plotShadow: false,
      type: 'pie'
    },
    title: {
      text: 'Desempenho'
    },
    tooltip: {
      pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
      pie: {
        allowPointSelect: true,
        cursor: 'pointer',
        dataLabels: {
          enabled: true,
          format: '<b>{point.name}</b>: {point.percentage:.1f} %',
          style: {
            color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
          }
        }
      }
    },
    series: [{
      name: 'Brands',
      colorByPoint: true,
      data: pieData
    }]
  });